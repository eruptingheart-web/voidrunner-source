# VOIDRUNNER

A small, asset-free arcade survival game built with vanilla JavaScript, HTML, and Canvas. No framework, package install, image files, audio files, or build step required.

## Run locally

Browsers restrict JavaScript modules opened through `file://`, so serve the folder over HTTP:

```bash
python3 -m http.server 8000
```

Then open <http://localhost:8000>.

You can also use any static-file server. There are no runtime dependencies.

## Controls

- **WASD** or **Arrow keys** — move
- **Mouse** — aim
- **Left mouse button** or **Space** — fire
- **Shift** — dash (brief invulnerability; cooldown)
- **P** — pause / resume
- **Enter** — start or restart

## Gameplay

Destroy pursuing drones, avoid contact damage, and survive escalating waves. Larger drones take multiple hits. Your score and best score are shown in the HUD; the best score is stored locally in your browser.

## Project layout

- `index.html` — semantic page shell and HUD
- `src/main.js` — application bootstrap and animation loop
- `src/game.js` — game state, wave pacing, spawning, scoring
- `src/player.js` — movement, aiming, firing, dash and health
- `src/enemy.js` — enemy behavior and rendering
- `src/renderer.js` — canvas scene and background
- `src/input.js` — keyboard and pointer input
- `src/particles.js` — lightweight hit/death particles
- `src/collision.js` — collision helpers
- `src/math.js` — shared math and formatting helpers
- `src/audio.js` — synthesized Web Audio effects
- `src/ui.js` — menus, HUD and notifications
- `src/config.js` — gameplay tuning constants
- `src/styles.css` — responsive visual design

## Tuning

Edit `src/config.js` to change player speed, fire rate, dash timing, spawn rates, arena grid, and colors. Enemy movement and size ranges are in `src/enemy.js`.

## Accessibility and browser notes

The game is keyboard playable. Pointer aiming is designed for mouse or touch. Audio is synthesized at runtime and begins only after the player starts a run. The game is designed for modern browsers with Canvas, ES modules, and Web Audio support.

## Contributing

Fork the project, make a focused change, and open a pull request with a short explanation and test steps. Keep the game asset-free unless a contribution explicitly changes that design goal.

## License

MIT. See [LICENSE](LICENSE).
