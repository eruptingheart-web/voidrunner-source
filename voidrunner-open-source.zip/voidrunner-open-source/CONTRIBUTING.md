# Contributing to VOIDRUNNER

Thanks for considering a contribution.

1. Open an issue describing the bug or proposed change before large changes.
2. Keep modules focused and use the existing vanilla-JS architecture.
3. Do not add binary assets or runtime dependencies without discussing the trade-off.
4. Test in a current Chromium- or Firefox-based browser at desktop and narrow viewport sizes.
5. Include reproduction steps for bug fixes and explain gameplay changes in pull requests.

## Code style

Use modern JavaScript modules, two-space indentation, descriptive names, and no semicolons are optional but consistency within a file matters. Prefer small functions and keep gameplay tuning in `src/config.js`.
